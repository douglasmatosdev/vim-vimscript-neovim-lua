# Atualização do Curso de Vim Moderno com Nevim
+ Sistema: Ubuntu 22.04 Jammy Jellyfish (development branch)

---

1. Atualize seu sistema:
```sh
sudo apt update
sudo apt upgrade -y
sudo apt autoremove -y
sudo apt autoclean
sudo apt clean
```

---

2. Instale as dependências
```sh
sudo apt install neovim git curl gcc g++ lua-filesystem clang clangd
```
> Teste com o comando: `nvim`

---

3. Recrie o diretório de configuração:
```sh
mkdir -p ~/.config/nvim
```

---

4. Inicio das customizações
> <https://terminalroot.com.br/2021/11/tudo-sobre-neovim-com-lua-como-customizar-do-zero.html>

---

```lua
if extension == "cpp" or extension == "hpp" then
  require'lspconfig'.clangd.setup{
    filetypes = { "c", "cpp", "hpp", "h" },
    dirname = {"/home/marcos/.config/clangd"},
    cmd = {
      "clangd", "--background-index", "--pch-storage=memory",
      "--clang-tidy", "--suggest-missing-includes",
      "--compile-commands-dir=/home/marcos/.config/clangd"
    },
    init_option = {
      fallbackFlags = {
        {"std=c++17"}
      }
    }
  }
else
  require'lspconfig'.clangd.setup{
    filetypes = { "c", "cpp", "hpp", "h" },
    dirname = {"/home/marcos/.config/clangd"},
  }
end
```


```sh
mkdir -p ~/.config/clangd
nvim ~/.config/clangd/compile_flags.txt
```

```txt
g++
-std=c++17
```

# Para LSP da sua linguagem de programação
> <https://github.com/neovim/nvim-lspconfig/blob/master/doc/server_configurations.md>

---

# Plugins Adicionais

+ Para saber sobre o Pie menu e o Eovim, vá aqui: <https://www.youtube.com/watch?v=8Hc7KNd6FU8>

---

# Plugins especiais:
1. <https://github.com/kyazdani42/nvim-tree.lua> e em `mapping.lua`:

```lua
-- NvimTree
vim.cmd([[ nnoremap <C-n> :NvimTreeOpen<CR> ]])
vim.cmd([[ inoremap <C-n> <Esc>:NvimTreeOpen<CR>l ]])
vim.cmd([[ vnoremap <C-n> <Esc>:NvimTreeOpen<CR> ]])
```

+ Para quando clicar em algo no NvimTree, abrir em uma nova aba: <https://github.com/akinsho/bufferline.nvim#installation>
> `lua/plugins/plugins.lua`

```lua
-- using packer.nvim
use {'akinsho/bufferline.nvim', tag = "*", requires = 'kyazdani42/nvim-web-devicons'}
```

> `utils.lua` : <https://github.com/akinsho/bufferline.nvim#usage>
```lua
require("bufferline").setup{}
```

---

2. Vim move: <https://github.com/matze/vim-move>

```lua
-- plugins.lua:
use 'matze/vim-move'

-- mappings.lua
-- Vim Move
vim.cmd([[ let g:move_key_modifier = 'C' ]]) -- Use o 'C' porque o 'S' já é do Surround
```
Comando: `Ctrl + (k/j)` - sobe e desce uma linha
Comando: `Alt + (k/j)` - sobe e desce um bloco após selecionado pelo modo visual(v ou mouse). Ou na vertical (l/h), direita/esquerda

---

3. Vim Notify: <https://github.com/rcarriga/nvim-notify>

```lua
------------------------ plugins.lua:
use 'rcarriga/nvim-notify'

------------------------ utils.lua , SEM ISSO FUNCIONA, MAS SEM TEMPO E OUTRAS CONFIGURAÇÕES
  require("notify").setup({
  -- Minimum level to show
  level = "info",

  -- Animation style (see below for details)
  stages = "fade_in_slide_out",

  -- Function called when a new window is opened, use for changing win settings/config
  on_open = nil,

  -- Function called when a window is closed
  on_close = nil,

  -- Render function for notifications. See notify-render()
  render = "default",

  -- Default timeout for notifications
  timeout = 3000,

  -- Max number of columns for messages
  max_width = nil,
  -- Max number of lines for a message
  max_height = nil,

  -- For stages that change opacity this is treated as the highlight behind the window
  -- Set this to either a highlight group, an RGB hex value e.g. "#000000" or a function returning an RGB code for dynamic values
  background_colour = "Normal",

  -- Minimum width for notification windows
  minimum_width = 50,

  -- Icons for the different levels
  icons = {
    ERROR = "",
    WARN = "",
    INFO = "",
    DEBUG = "",
    TRACE = "✎",
  },
})

----------------------------- PARA CHAMAR, exemplo se o arquivo não tiver a extensão tal:
if extension == "cpp" or extension == "hpp" or extension == "h" then
  this_lsp = '-lsp_name'
else
  this_lsp = '-file_size'
  require("notify")("Esse arquivo não tem suporte para LSP")
end

```

---

4. FloatTerm: <https://github.com/voldikss/vim-floaterm>

```lua
--- plugins.lua:
use 'voldikss/vim-floaterm'

--- Comando para abrir o terminal:
:FloatermNew
-- Ou :FloatermToggle
```

---

5. Dashboard: <https://github.com/glepnir/dashboard-nvim>

```lua
-- plugins.lua:
use 'glepnir/dashboard-nvim'

-- Ao abrir somente o comando 'nvim', já funciona, 
-- mas se quiser configurações adicionais adicione:
-- dashboard.lua e "chame no init.lua", segue o conteúdo para pôr nele:
-- Lembrando que o plugin está sendo reescrito em Lua, logo algumas
-- opções do menu não funcionarão
```

---

