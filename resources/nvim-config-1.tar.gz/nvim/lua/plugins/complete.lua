if extension == "md" then
  require("plugins.tabnine")
else
  require("plugins.lsp")
end
