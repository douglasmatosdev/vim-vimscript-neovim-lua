if extension == "md" then
  require("plugins.tabnine")
  require("notify")("Esse arquivo não tem suporte à LSP.")
else
  require("plugins.lsp")
end
