#!/bin/bash

echo "Teste"
var="nada"

algo_tudo(){
	echo Teste
}
