#!/usr/env/python
def Teste():
    print("Meu código em Python")
Teste()
